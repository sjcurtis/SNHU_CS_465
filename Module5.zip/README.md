# SNHU_CS_465

# Install dependencies
npm install

# Start Webserver
SET DEBUG=travlr:*
npm start

navigate to localhost:3000

# Seeding Database
npx seedgoose seed